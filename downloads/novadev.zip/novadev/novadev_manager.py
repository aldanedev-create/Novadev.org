from __future__ import annotations

"""NovaDev Manager for projects, packages, diagnostics, and uninstall."""

import os
import re
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk

from novadev.paths import is_source_path, source_workspace


ROOT = Path(__file__).resolve().parent
NOVA = ROOT / "nova.py"
NOVAPM = ROOT / "novapm.py"
EXAMPLES = ROOT / "examples"
INSTALL_HOME = Path(os.environ.get("NOVADEV_HOME", ROOT.parent if ROOT.name.lower() == "language" else ROOT)).resolve()
WORKSPACE = source_workspace()


class NovaDevManager(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("NovaDev Manager")
        self.geometry("1120x720")
        self.minsize(900, 620)

        self.status_var = tk.StringVar(value="Ready")
        self.search_var = tk.StringVar()
        self.project_name_var = tk.StringVar()
        self.frontend_var = tk.StringVar(value="Vue")
        self.backend_var = tk.StringVar(value="Flask")
        self.selected_path_var = tk.StringVar(value=str(WORKSPACE))
        self.item_paths: dict[str, tuple[Path, str]] = {}
        self.command_running = False

        self.configure(bg="#17191d")
        self.build_style()
        self.set_icon()
        self.build_ui()
        self.refresh_files()

    def build_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#17191d")
        style.configure("Panel.TFrame", background="#202329")
        style.configure("TLabel", background="#17191d", foreground="#f3f4f6")
        style.configure("Panel.TLabel", background="#202329", foreground="#f3f4f6")
        style.configure("Muted.TLabel", background="#17191d", foreground="#a7adb7")
        style.configure("PanelMuted.TLabel", background="#202329", foreground="#a7adb7")
        style.configure("TButton", padding=(10, 7))
        style.configure("Danger.TButton", padding=(10, 7), foreground="#fee2e2", background="#7f1d1d")
        style.configure("TNotebook", background="#17191d", borderwidth=0)
        style.configure("TNotebook.Tab", padding=(14, 8))
        style.configure("Treeview", rowheight=28, background="#17191d", fieldbackground="#17191d", foreground="#f3f4f6")
        style.configure("Treeview.Heading", background="#292d34", foreground="#f3f4f6")

    def set_icon(self) -> None:
        candidates = [INSTALL_HOME / "assets" / "novadev.ico", ROOT / "assets" / "icons" / "novadev.ico"]
        for candidate in candidates:
            if candidate.exists():
                try:
                    self.iconbitmap(default=str(candidate))
                    return
                except tk.TclError:
                    pass

    def build_ui(self) -> None:
        header = ttk.Frame(self, padding=(18, 14))
        header.pack(fill="x")

        mark = tk.Label(header, text="ND", width=4, height=2, bg="#22c55e", fg="#052e16", font=("Segoe UI", 11, "bold"))
        mark.pack(side="left")
        title_box = ttk.Frame(header)
        title_box.pack(side="left", padx=12)
        ttk.Label(title_box, text="NovaDev Manager", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(title_box, text="Create, find, build, and manage NovaDev projects.", style="Muted.TLabel").pack(anchor="w")

        header_actions = ttk.Frame(header)
        header_actions.pack(side="right")
        ttk.Button(header_actions, text="Open Source Folder", command=lambda: self.open_path(WORKSPACE)).pack(side="left", padx=(0, 8))
        ttk.Button(header_actions, text="Open Shell", command=self.open_shell).pack(side="left")

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        self.build_projects_tab()
        self.build_commands_tab()
        self.build_packages_tab()
        self.build_system_tab()
        self.build_help_tab()

        status = ttk.Frame(self, padding=(10, 4))
        status.pack(fill="x")
        ttk.Label(status, textvariable=self.status_var, anchor="w").pack(side="left", fill="x", expand=True)
        ttk.Label(status, text=str(WORKSPACE), style="Muted.TLabel").pack(side="right")

    def build_projects_tab(self) -> None:
        frame = ttk.Frame(self.notebook, style="Panel.TFrame", padding=14)
        self.notebook.add(frame, text="Projects and Files")

        create_row = ttk.Frame(frame, style="Panel.TFrame")
        create_row.pack(fill="x", pady=(0, 12))
        ttk.Label(create_row, text="New project", style="Panel.TLabel").pack(side="left", padx=(0, 8))
        ttk.Entry(create_row, textvariable=self.project_name_var, width=28).pack(side="left", padx=(0, 8))
        ttk.Combobox(create_row, textvariable=self.frontend_var, values=("Vue", "HTML", "VueVite"), state="readonly", width=11).pack(side="left", padx=(0, 8))
        ttk.Combobox(create_row, textvariable=self.backend_var, values=("Flask", "Express"), state="readonly", width=11).pack(side="left", padx=(0, 8))
        ttk.Button(create_row, text="Create", command=self.create_project).pack(side="left")

        search_row = ttk.Frame(frame, style="Panel.TFrame")
        search_row.pack(fill="x", pady=(0, 8))
        ttk.Label(search_row, text="Find", style="Panel.TLabel").pack(side="left", padx=(0, 8))
        search_entry = ttk.Entry(search_row, textvariable=self.search_var)
        search_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        search_entry.bind("<Return>", lambda _event: self.refresh_files())
        ttk.Button(search_row, text="Search", command=self.refresh_files).pack(side="left", padx=(0, 8))
        ttk.Button(search_row, text="Clear", command=self.clear_search).pack(side="left")

        table_frame = ttk.Frame(frame, style="Panel.TFrame")
        table_frame.pack(fill="both", expand=True)
        self.file_tree = ttk.Treeview(table_frame, columns=("kind", "path"), show="headings", selectmode="browse")
        self.file_tree.heading("kind", text="Type")
        self.file_tree.heading("path", text="Location")
        self.file_tree.column("kind", width=120, stretch=False)
        self.file_tree.column("path", width=720)
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.file_tree.yview)
        self.file_tree.configure(yscrollcommand=scrollbar.set)
        self.file_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.file_tree.bind("<<TreeviewSelect>>", self.on_file_selected)
        self.file_tree.bind("<Double-1>", lambda _event: self.open_selected())

        selected_row = ttk.Frame(frame, style="Panel.TFrame")
        selected_row.pack(fill="x", pady=(10, 0))
        ttk.Label(selected_row, textvariable=self.selected_path_var, style="PanelMuted.TLabel").pack(side="left", fill="x", expand=True)
        ttk.Button(selected_row, text="Open", command=self.open_selected).pack(side="left", padx=(8, 0))
        ttk.Button(selected_row, text="Run", command=self.run_selected).pack(side="left", padx=(8, 0))
        ttk.Button(selected_row, text="Build UI", command=self.build_selected_ui).pack(side="left", padx=(8, 0))
        ttk.Button(selected_row, text="Build App", command=self.build_selected_app).pack(side="left", padx=(8, 0))
        ttk.Button(selected_row, text="Delete", style="Danger.TButton", command=self.delete_selected).pack(side="left", padx=(8, 0))

    def build_commands_tab(self) -> None:
        frame = ttk.Frame(self.notebook, style="Panel.TFrame", padding=14)
        self.notebook.add(frame, text="Command Output")
        actions = ttk.Frame(frame, style="Panel.TFrame")
        actions.pack(fill="x", pady=(0, 10))
        example = EXAMPLES / "hello.nova"
        ttk.Button(actions, text="Run Hello", command=lambda: self.run_command([sys.executable, str(NOVA), "run", str(example)])).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Show Tokens", command=lambda: self.run_command([sys.executable, str(NOVA), "tokens", str(example)])).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Show AST", command=lambda: self.run_command([sys.executable, str(NOVA), "ast", str(example)])).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Clear Output", command=self.clear_output).pack(side="left")
        self.output = scrolledtext.ScrolledText(frame, bg="#0f1115", fg="#f8fafc", insertbackground="#f8fafc", font=("Consolas", 10), wrap="word")
        self.output.pack(fill="both", expand=True)

    def build_packages_tab(self) -> None:
        frame = ttk.Frame(self.notebook, style="Panel.TFrame", padding=14)
        self.notebook.add(frame, text="Packages")
        ttk.Label(frame, text="NovaDev Package Manager", style="Panel.TLabel", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Inspect the registry and locally installed Nova packages.", style="PanelMuted.TLabel").pack(anchor="w", pady=(0, 12))
        buttons = ttk.Frame(frame, style="Panel.TFrame")
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Doctor", command=lambda: self.run_package_command("doctor")).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Search", command=lambda: self.run_package_command("search")).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="List Installed", command=lambda: self.run_package_command("list")).pack(side="left")

    def build_system_tab(self) -> None:
        frame = ttk.Frame(self.notebook, style="Panel.TFrame", padding=14)
        self.notebook.add(frame, text="System")
        ttk.Label(frame, text="Installation", style="Panel.TLabel", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        details = (
            f"Python: {sys.executable}\n"
            f"NovaDev language: {ROOT}\n"
            f"Install home: {INSTALL_HOME}\n"
            f"User source: {WORKSPACE}\n\n"
            "Uninstall removes NovaDev launchers, packages, file associations, and installed runtime files. "
            "Projects in Nova source code are preserved unless you delete them yourself."
        )
        ttk.Label(frame, text=details, style="PanelMuted.TLabel", justify="left", wraplength=850).pack(anchor="w", pady=(8, 16))
        actions = ttk.Frame(frame, style="Panel.TFrame")
        actions.pack(fill="x")
        ttk.Button(actions, text="Verify Installation", command=self.verify_installation).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Open Install Folder", command=lambda: self.open_path(INSTALL_HOME)).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Open Manager Log", command=self.open_manager_log).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Uninstall NovaDev", style="Danger.TButton", command=self.uninstall_novadev).pack(side="right")

    def build_help_tab(self) -> None:
        frame = ttk.Frame(self.notebook, style="Panel.TFrame", padding=14)
        self.notebook.add(frame, text="Help")
        text = (
            "NovaDev creates projects here by default:\n"
            f"  {WORKSPACE}\n\n"
            "PowerShell and shell commands:\n\n"
            "  nova new MyProject\n"
            "  nova shell\n"
            "  nova run app.nova\n"
            "  nova build-fullstack MyProject -o generated\n"
            "  novapm doctor\n\n"
            "Use Projects and Files to find or delete Nova source safely. Deletion is restricted to the Nova source folder.\n"
            "Use System to verify or uninstall the installed language."
        )
        help_box = scrolledtext.ScrolledText(frame, bg="#0f1115", fg="#f8fafc", font=("Consolas", 10), wrap="word")
        help_box.pack(fill="both", expand=True)
        help_box.insert("1.0", text)
        help_box.configure(state="disabled")

    def clear_search(self) -> None:
        self.search_var.set("")
        self.refresh_files()

    def refresh_files(self) -> None:
        WORKSPACE.mkdir(parents=True, exist_ok=True)
        query = self.search_var.get().strip().lower()
        rows: list[tuple[Path, str]] = []

        project_dirs = sorted({path.parent for path in WORKSPACE.rglob("app.nova")})
        for project in project_dirs:
            relative = project.relative_to(WORKSPACE).as_posix()
            if not query or query in relative.lower():
                rows.append((project, "Project"))

        for source_file in sorted(WORKSPACE.rglob("*.nova")):
            if source_file.name == "app.nova" and source_file.parent in project_dirs:
                continue
            relative = source_file.relative_to(WORKSPACE).as_posix()
            if not query or query in relative.lower():
                rows.append((source_file, "Nova source"))

        self.file_tree.delete(*self.file_tree.get_children())
        self.item_paths.clear()
        for index, (path, kind) in enumerate(rows[:2000]):
            item_id = f"item-{index}"
            self.item_paths[item_id] = (path, kind)
            self.file_tree.insert("", "end", iid=item_id, values=(kind, path.relative_to(WORKSPACE).as_posix()))
        self.status_var.set(f"Found {len(rows)} NovaDev project/file item(s)")

    def on_file_selected(self, _event=None) -> None:
        selected = self.file_tree.selection()
        if selected and selected[0] in self.item_paths:
            self.selected_path_var.set(str(self.item_paths[selected[0]][0]))

    def selected_item(self) -> tuple[Path, str] | None:
        selected = self.file_tree.selection()
        return self.item_paths.get(selected[0]) if selected else None

    def selected_project(self) -> Path | None:
        item = self.selected_item()
        if not item:
            return None
        path, kind = item
        if kind == "Project":
            return path
        for parent in [path.parent, *path.parents]:
            if parent == WORKSPACE.parent:
                break
            if (parent / "app.nova").exists():
                return parent
        return None

    def create_project(self) -> None:
        name = self.project_name_var.get().strip()
        if not name or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _-]{0,79}", name):
            messagebox.showerror("NovaDev Manager", "Use a project name containing letters, numbers, spaces, hyphens, or underscores.")
            return
        command = [
            sys.executable,
            str(NOVA),
            "new",
            name,
            "--frontend",
            self.frontend_var.get(),
            "--backend",
            self.backend_var.get(),
        ]
        self.run_command(command, on_success=self.project_created)

    def project_created(self) -> None:
        self.project_name_var.set("")
        self.refresh_files()
        self.notebook.select(0)

    def open_selected(self) -> None:
        item = self.selected_item()
        if not item:
            messagebox.showinfo("NovaDev Manager", "Select a project or Nova source file first.")
            return
        self.open_path(item[0])

    def run_selected(self) -> None:
        item = self.selected_item()
        if not item:
            messagebox.showinfo("NovaDev Manager", "Select a project or Nova source file first.")
            return
        source = item[0] / "app.nova" if item[1] == "Project" else item[0]
        self.run_command([sys.executable, str(NOVA), "run", str(source)])

    def build_selected_ui(self) -> None:
        project = self.selected_project()
        if not project:
            messagebox.showinfo("NovaDev Manager", "Select a NovaDev project first.")
            return
        self.run_command([sys.executable, str(NOVA), "build-ui", str(project), "-o", str(project / "dist")])

    def build_selected_app(self) -> None:
        project = self.selected_project()
        if not project:
            messagebox.showinfo("NovaDev Manager", "Select a NovaDev project first.")
            return
        self.run_command([sys.executable, str(NOVA), "build-fullstack", str(project), "-o", str(project / "generated")])

    def delete_selected(self) -> None:
        item = self.selected_item()
        if not item:
            messagebox.showinfo("NovaDev Manager", "Select a project or source file first.")
            return
        path, kind = item
        if not is_source_path(path):
            messagebox.showerror("NovaDev Manager", "NovaDev will only delete items inside the Nova source code folder.")
            return
        if not messagebox.askyesno("Delete Nova source", f"Delete this {kind.lower()}?\n\n{path}\n\nThis cannot be undone."):
            return
        try:
            if path.is_dir():
                shutil.rmtree(path)
            elif path.exists():
                path.unlink()
            self.selected_path_var.set(str(WORKSPACE))
            self.refresh_files()
        except OSError as error:
            messagebox.showerror("NovaDev Manager", f"Could not delete:\n{path}\n\n{error}")

    def run_package_command(self, command: str) -> None:
        self.notebook.select(1)
        self.run_command([sys.executable, str(NOVAPM), command])

    def verify_installation(self) -> None:
        self.notebook.select(1)
        self.run_command([sys.executable, str(NOVA), "--version"])

    def open_shell(self) -> None:
        command = [sys.executable, str(NOVA), "shell"]
        try:
            kwargs: dict[str, object] = {"cwd": str(WORKSPACE)}
            if os.name == "nt":
                kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
            subprocess.Popen(command, **kwargs)
            self.status_var.set("Opened NovaDev shell in Nova source code")
        except OSError as error:
            messagebox.showerror("NovaDev Manager", str(error))

    def run_command(self, command: list[str], on_success=None) -> None:
        if self.command_running:
            messagebox.showinfo("NovaDev Manager", "Wait for the current command to finish.")
            return
        self.command_running = True
        self.status_var.set("Running " + " ".join(command[1:3]))
        self.write_output("\n$ " + subprocess.list2cmdline(command) + "\n")
        self.notebook.select(1)

        def worker() -> None:
            try:
                creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                completed = subprocess.run(
                    command,
                    cwd=str(WORKSPACE),
                    text=True,
                    capture_output=True,
                    timeout=180,
                    creationflags=creationflags,
                )
                text = (completed.stdout or "") + (completed.stderr or "")
                self.after(0, lambda: self.finish_command(completed.returncode, text, on_success))
            except Exception as error:  # noqa: BLE001 - display command errors in the GUI.
                self.after(0, lambda: self.finish_command(1, f"error: {error}\n", None))

        threading.Thread(target=worker, daemon=True).start()

    def finish_command(self, returncode: int, text: str, on_success) -> None:
        self.command_running = False
        if text:
            self.write_output(text)
        self.status_var.set("Command finished" if returncode == 0 else f"Command failed with exit code {returncode}")
        if returncode == 0 and on_success:
            on_success()

    def clear_output(self) -> None:
        self.output.delete("1.0", "end")

    def write_output(self, text: str) -> None:
        self.output.insert("end", text)
        self.output.see("end")

    def open_manager_log(self) -> None:
        log = INSTALL_HOME / "logs" / "manager.log"
        if not log.exists():
            messagebox.showinfo("NovaDev Manager", f"No manager log exists yet.\n\nExpected location:\n{log}")
            return
        self.open_path(log)

    def open_path(self, path: Path) -> None:
        target = path if path.exists() else path.parent
        try:
            if os.name == "nt":
                if target.is_file():
                    subprocess.Popen(["explorer.exe", "/select,", str(target)])
                else:
                    os.startfile(str(target))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(target)])
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except OSError as error:
            messagebox.showerror("NovaDev Manager", f"Could not open:\n{target}\n\n{error}")

    def uninstall_novadev(self) -> None:
        uninstallers = sorted(INSTALL_HOME.glob("unins*.exe"))
        portable = ROOT / "uninstall_novadev.py"
        if not uninstallers and not portable.exists():
            messagebox.showinfo(
                "NovaDev Manager",
                "This appears to be a source checkout, not an installed copy. Use the installer or remove the checkout manually.",
            )
            return
        if not messagebox.askyesno(
            "Uninstall NovaDev",
            "Remove the NovaDev runtime, launchers, packages, and file association?\n\nProjects in Downloads\\Nova source code will be kept.",
        ):
            return
        try:
            if uninstallers:
                subprocess.Popen([str(uninstallers[0])], cwd=str(INSTALL_HOME))
            else:
                flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                subprocess.Popen(
                    [sys.executable, str(portable), "--home", str(INSTALL_HOME), "--yes", "--parent-pid", str(os.getpid())],
                    cwd=str(Path.home()),
                    creationflags=flags,
                )
            self.after(250, self.destroy)
        except OSError as error:
            messagebox.showerror("NovaDev Manager", f"Could not start the uninstaller.\n\n{error}")


def main() -> int:
    if "--self-test" in sys.argv:
        missing = [path for path in (NOVA, NOVAPM) if not path.exists()]
        if missing:
            for path in missing:
                print(f"missing: {path}")
            return 1
        import tkinter  # noqa: F401

        print("NovaDev Manager self-test passed")
        print(f"Install home: {INSTALL_HOME}")
        print(f"Source workspace: {WORKSPACE}")
        return 0

    if not NOVA.exists():
        messagebox.showerror("NovaDev Manager", f"Could not find nova.py at:\n{NOVA}")
        return 1
    app = NovaDevManager()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
