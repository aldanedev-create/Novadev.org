from __future__ import annotations

"""NovaDev Manager GUI.

This is the first desktop manager for NovaDev. It uses only Python's standard
library, so it can run anywhere Python and Tkinter are available. The manager is
designed to work from the source tree and from a Windows installer layout.
"""

import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path
from tkinter import END, BOTH, LEFT, RIGHT, X, Y, Tk, StringVar, Text, messagebox
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText


DEFAULT_ZIP_URL = "https://novadev-org.vercel.app/downloads/novadev.zip"
DEFAULT_REGISTRY_URL = "https://novadev-org.vercel.app/downloads/registry.json"


class NovaDevManagerApp:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.root.title("NovaDev Manager")
        self.root.geometry("980x680")
        self.root.minsize(860, 560)

        self.home = self.detect_home()
        self.language_dir = self.detect_language_dir()
        self.output_queue: queue.Queue[str] = queue.Queue()

        self.zip_url = StringVar(value=DEFAULT_ZIP_URL)
        self.registry_url = StringVar(value=DEFAULT_REGISTRY_URL)
        self.package_query = StringVar(value="")
        self.package_name = StringVar(value="")
        self.home_value = StringVar(value=str(self.home))
        self.status_value = StringVar(value="Ready")

        self.build_ui()
        self.refresh_status()
        self.root.after(100, self.drain_output_queue)

    def detect_home(self) -> Path:
        env_home = os.environ.get("NOVADEV_HOME")
        if env_home:
            return Path(env_home).expanduser().resolve()

        current = Path(__file__).resolve()
        if current.parent.name == "language":
            return current.parent.parent.resolve()

        return (Path.home() / ".novadev").resolve()

    def detect_language_dir(self) -> Path:
        if (self.home / "language" / "nova.py").exists():
            return self.home / "language"
        return Path(__file__).resolve().parent

    def build_ui(self) -> None:
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Section.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Accent.TButton", padding=(10, 6))

        top = ttk.Frame(self.root, padding=16)
        top.pack(fill=X)

        title_box = ttk.Frame(top)
        title_box.pack(side=LEFT, fill=X, expand=True)
        ttk.Label(title_box, text="NovaDev Manager", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            title_box,
            text="Install NovaDev, manage packages, open the shell, and check your local setup.",
        ).pack(anchor="w")

        ttk.Button(top, text="Refresh Status", command=self.refresh_status).pack(side=RIGHT)

        ttk.Label(self.root, textvariable=self.status_value, padding=(16, 0, 16, 8)).pack(fill=X)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=BOTH, expand=True, padx=16, pady=(0, 16))

        self.status_tab = ttk.Frame(notebook, padding=14)
        self.install_tab = ttk.Frame(notebook, padding=14)
        self.packages_tab = ttk.Frame(notebook, padding=14)
        self.output_tab = ttk.Frame(notebook, padding=14)

        notebook.add(self.status_tab, text="Status")
        notebook.add(self.install_tab, text="Install / Update")
        notebook.add(self.packages_tab, text="Packages")
        notebook.add(self.output_tab, text="Output")

        self.build_status_tab()
        self.build_install_tab()
        self.build_packages_tab()
        self.build_output_tab()

    def build_status_tab(self) -> None:
        info = ttk.LabelFrame(self.status_tab, text="Local Installation", padding=12)
        info.pack(fill=X)

        rows = [
            ("NovaDev home", self.home_value),
            ("Language folder", StringVar(value=str(self.language_dir))),
            ("Default registry", self.registry_url),
        ]
        for index, (label, value) in enumerate(rows):
            ttk.Label(info, text=label, style="Section.TLabel").grid(row=index, column=0, sticky="w", pady=4)
            ttk.Label(info, textvariable=value).grid(row=index, column=1, sticky="w", padx=12, pady=4)
        info.columnconfigure(1, weight=1)

        actions = ttk.Frame(self.status_tab)
        actions.pack(fill=X, pady=14)
        ttk.Button(actions, text="Run Doctor", command=self.run_doctor).pack(side=LEFT, padx=(0, 8))
        ttk.Button(actions, text="Open Nova Shell", command=self.open_shell).pack(side=LEFT, padx=(0, 8))
        ttk.Button(actions, text="Run Hello Example", command=self.run_hello).pack(side=LEFT, padx=(0, 8))
        ttk.Button(actions, text="Open Install Folder", command=self.open_install_folder).pack(side=LEFT, padx=(0, 8))

        help_box = ttk.LabelFrame(self.status_tab, text="PATH Hint", padding=12)
        help_box.pack(fill=X)
        ttk.Label(
            help_box,
            text=(
                "For terminal commands to work anywhere, add the bin folder to PATH:\n"
                f"{self.home / 'bin'}"
            ),
        ).pack(anchor="w")

    def build_install_tab(self) -> None:
        form = ttk.LabelFrame(self.install_tab, text="Install or Update From Website", padding=12)
        form.pack(fill=X)

        ttk.Label(form, text="NovaDev zip URL", style="Section.TLabel").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=self.zip_url).grid(row=0, column=1, sticky="ew", padx=12, pady=4)

        ttk.Label(form, text="Registry URL", style="Section.TLabel").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=self.registry_url).grid(row=1, column=1, sticky="ew", padx=12, pady=4)
        form.columnconfigure(1, weight=1)

        buttons = ttk.Frame(self.install_tab)
        buttons.pack(fill=X, pady=14)
        ttk.Button(
            buttons,
            text="Install / Update NovaDev",
            style="Accent.TButton",
            command=lambda: self.install_or_update(install_all=False),
        ).pack(side=LEFT, padx=(0, 8))
        ttk.Button(
            buttons,
            text="Install / Update + All Packages",
            command=lambda: self.install_or_update(install_all=True),
        ).pack(side=LEFT, padx=(0, 8))
        ttk.Button(buttons, text="Configure Registry Only", command=self.configure_registry).pack(side=LEFT)

        note = ttk.LabelFrame(self.install_tab, text="What This Does", padding=12)
        note.pack(fill=BOTH, expand=True)
        ttk.Label(
            note,
            text=(
                "The manager downloads the website installer into a temporary folder, runs it with the selected zip URL, "
                "sets NOVADEV_HOME, writes launcher scripts, and configures novapm to use the registry URL."
            ),
            wraplength=840,
        ).pack(anchor="w")

    def build_packages_tab(self) -> None:
        search_box = ttk.LabelFrame(self.packages_tab, text="Search Registry", padding=12)
        search_box.pack(fill=X)

        ttk.Entry(search_box, textvariable=self.package_query).pack(side=LEFT, fill=X, expand=True, padx=(0, 8))
        ttk.Button(search_box, text="Search", command=self.search_packages).pack(side=LEFT)

        package_box = ttk.LabelFrame(self.packages_tab, text="Install or Remove Package", padding=12)
        package_box.pack(fill=X, pady=14)
        ttk.Entry(package_box, textvariable=self.package_name).pack(side=LEFT, fill=X, expand=True, padx=(0, 8))
        ttk.Button(package_box, text="Install", command=self.install_package).pack(side=LEFT, padx=(0, 8))
        ttk.Button(package_box, text="Remove", command=self.remove_package).pack(side=LEFT)

        actions = ttk.Frame(self.packages_tab)
        actions.pack(fill=X)
        ttk.Button(actions, text="List Installed Packages", command=self.list_packages).pack(side=LEFT, padx=(0, 8))
        ttk.Button(actions, text="Show Registry Info", command=self.show_registry_info).pack(side=LEFT)

    def build_output_tab(self) -> None:
        self.output = ScrolledText(self.output_tab, height=20, wrap="word")
        self.output.pack(fill=BOTH, expand=True)

        buttons = ttk.Frame(self.output_tab)
        buttons.pack(fill=X, pady=(8, 0))
        ttk.Button(buttons, text="Clear Output", command=lambda: self.output.delete("1.0", END)).pack(side=LEFT)

    def nova_script(self) -> Path:
        return self.language_dir / "nova.py"

    def novapm_script(self) -> Path:
        return self.language_dir / "novapm.py"

    def append_output(self, text: str) -> None:
        self.output_queue.put(text)

    def drain_output_queue(self) -> None:
        while True:
            try:
                text = self.output_queue.get_nowait()
            except queue.Empty:
                break
            self.output.insert(END, text)
            self.output.see(END)
        self.root.after(100, self.drain_output_queue)

    def run_background(self, title: str, args: list[str], cwd: Path | None = None) -> None:
        self.status_value.set(f"Running: {title}")
        self.append_output(f"\n$ {' '.join(args)}\n")

        def worker() -> None:
            env = os.environ.copy()
            env["NOVADEV_HOME"] = str(self.home)
            process = subprocess.Popen(
                args,
                cwd=str(cwd or self.language_dir),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            assert process.stdout is not None
            for line in process.stdout:
                self.append_output(line)
            code = process.wait()
            self.append_output(f"[exit {code}]\n")
            self.status_value.set("Ready" if code == 0 else f"Command failed: {title}")

        threading.Thread(target=worker, daemon=True).start()

    def run_novapm(self, args: list[str]) -> None:
        if not self.novapm_script().exists():
            messagebox.showerror("NovaDev Manager", "novapm.py was not found. Install NovaDev first.")
            return
        self.run_background("novapm " + " ".join(args), [sys.executable, str(self.novapm_script()), *args])

    def run_doctor(self) -> None:
        self.run_novapm(["doctor", "--home", str(self.home)])

    def run_hello(self) -> None:
        if not self.nova_script().exists():
            messagebox.showerror("NovaDev Manager", "nova.py was not found. Install NovaDev first.")
            return
        self.run_background("nova run examples/hello.nova", [sys.executable, str(self.nova_script()), "run", "examples/hello.nova"])

    def search_packages(self) -> None:
        query = self.package_query.get().strip()
        args = ["search"]
        if query:
            args.append(query)
        args.extend(["--home", str(self.home)])
        self.run_novapm(args)

    def list_packages(self) -> None:
        self.run_novapm(["list", "--home", str(self.home)])

    def install_package(self) -> None:
        name = self.package_name.get().strip()
        if not name:
            messagebox.showinfo("NovaDev Manager", "Enter a package name first.")
            return
        self.run_novapm(["install", name, "--home", str(self.home)])

    def remove_package(self) -> None:
        name = self.package_name.get().strip()
        if not name:
            messagebox.showinfo("NovaDev Manager", "Enter a package name first.")
            return
        if not messagebox.askyesno("Remove Package", f"Remove package '{name}'?"):
            return
        self.run_novapm(["remove", name, "--home", str(self.home)])

    def show_registry_info(self) -> None:
        config_path = self.home / "config.json"
        if config_path.exists():
            self.append_output("\nconfig.json\n")
            self.append_output(config_path.read_text(encoding="utf-8") + "\n")
        else:
            self.append_output("\nNo config.json found yet.\n")

    def configure_registry(self) -> None:
        registry = self.registry_url.get().strip()
        if not registry:
            messagebox.showinfo("NovaDev Manager", "Enter a registry URL first.")
            return
        self.home.mkdir(parents=True, exist_ok=True)
        config_path = self.home / "config.json"
        config_path.write_text(json.dumps({"registry": registry}, indent=2) + "\n", encoding="utf-8")
        self.append_output(f"\nConfigured registry: {registry}\n")
        self.refresh_status()

    def install_or_update(self, install_all: bool) -> None:
        zip_url = self.zip_url.get().strip()
        registry_url = self.registry_url.get().strip()
        if not zip_url:
            messagebox.showinfo("NovaDev Manager", "Enter a NovaDev zip URL first.")
            return

        def worker() -> None:
            self.status_value.set("Downloading installer...")
            self.append_output("\nDownloading NovaDev installer...\n")
            try:
                with tempfile.TemporaryDirectory(prefix="novadev-manager-") as temp:
                    installer = Path(temp) / "install-novadev.py"
                    urllib.request.urlretrieve(
                        "https://novadev-org.vercel.app/downloads/install-novadev.py",
                        installer,
                    )
                    args = [
                        sys.executable,
                        str(installer),
                        "--zip-url",
                        zip_url,
                        "--home",
                        str(self.home),
                    ]
                    if registry_url:
                        args.extend(["--registry-url", registry_url])
                    if install_all:
                        args.append("--install-all-packages")
                    self.run_blocking("Install / Update NovaDev", args, Path(temp))
            except Exception as exc:  # noqa: BLE001 - GUI should report any install problem.
                self.append_output(f"Install failed: {exc}\n")
                self.status_value.set("Install failed")
                return
            self.language_dir = self.detect_language_dir()
            self.refresh_status()

        threading.Thread(target=worker, daemon=True).start()

    def run_blocking(self, title: str, args: list[str], cwd: Path) -> None:
        self.append_output(f"$ {' '.join(args)}\n")
        env = os.environ.copy()
        env["NOVADEV_HOME"] = str(self.home)
        process = subprocess.Popen(
            args,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        assert process.stdout is not None
        for line in process.stdout:
            self.append_output(line)
        code = process.wait()
        self.append_output(f"[exit {code}]\n")
        if code != 0:
            raise RuntimeError(f"{title} exited with code {code}")

    def open_shell(self) -> None:
        if not self.nova_script().exists():
            messagebox.showerror("NovaDev Manager", "nova.py was not found. Install NovaDev first.")
            return

        env_command = f'set "NOVADEV_HOME={self.home}"'
        command = f'{env_command} && cd /d "{self.language_dir}" && "{sys.executable}" "{self.nova_script()}" shell'
        if os.name == "nt":
            subprocess.Popen(["cmd.exe", "/k", command])
        else:
            subprocess.Popen(["sh", "-c", f'cd "{self.language_dir}" && NOVADEV_HOME="{self.home}" "{sys.executable}" "{self.nova_script()}" shell'])

    def open_install_folder(self) -> None:
        self.home.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            subprocess.Popen(["explorer", str(self.home)])
        else:
            subprocess.Popen(["xdg-open", str(self.home)])

    def refresh_status(self) -> None:
        self.home_value.set(str(self.home))
        language_ok = self.nova_script().exists()
        package_count = 0
        installed_path = self.home / "installed.json"
        if installed_path.exists():
            try:
                package_count = len(json.loads(installed_path.read_text(encoding="utf-8")).get("packages", {}))
            except json.JSONDecodeError:
                package_count = 0
        status = "Installed" if language_ok else "Not installed"
        self.status_value.set(f"{status} | packages: {package_count} | home: {self.home}")


def main() -> int:
    root = Tk()
    NovaDevManagerApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
