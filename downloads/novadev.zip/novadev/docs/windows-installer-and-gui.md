# NovaDev Windows Installer And Manager

NovaDev ships a per-user Windows installer built with Inno Setup 6 and a
dependency-free Tkinter desktop manager.

## Installed Components

```txt
%LOCALAPPDATA%\NovaDev\
  bin\
    nova.cmd
    nova-shell.cmd
    novapm.cmd
    novadev-manager.cmd
    novadev-manager.vbs
  language\
  packages\
  cache\
  logs\manager.log
  config.json
  installed.json
  unins000.exe
```

The launchers use `find-python.cmd` and the same detected Python executable or
`py -3` command. Paths containing spaces are quoted. Open a new PowerShell after
installation so it receives the updated user PATH.

## User Source Workspace

The installer creates and preserves:

```txt
%USERPROFILE%\Downloads\Nova source code
```

`nova new Name`, shell `.new Name`, and NovaDev Manager create projects there.
Set `NOVA_SOURCE_HOME` to an absolute folder only when an advanced user needs a
different source workspace.

## Manager Capabilities

- Create Vue, HTML, or VueVite projects with Flask or Express.
- Search projects and `.nova` files recursively.
- Reveal source in Windows Explorer.
- Run selected source and build UI/full-stack output.
- Safely delete a selected project/file after confirmation.
- Reject deletion outside `Nova source code`.
- Run package-manager doctor, search, and list commands.
- Verify the installation and open the Manager launch log.
- Start the Inno or portable NovaDev uninstaller.

Long commands run on a worker thread so the Tkinter window remains responsive.

## Uninstall

Use one of these paths:

1. NovaDev Manager → System → Uninstall NovaDev.
2. Windows Settings → Installed apps → NovaDev → Uninstall.
3. Start Menu → NovaDev → Uninstall NovaDev.
4. Portable install: run `uninstall-novadev`.

Uninstall removes the installed runtime, packages, launchers, PATH entry,
`.nova` association, and installed VS Code extension. It does not remove
projects in `Downloads\Nova source code`.

## Build Installer

Install Inno Setup 6, then run:

```powershell
.\installer\windows\build-installer.ps1
```

Output:

```txt
nova website\downloads\NovaDevSetup.exe
```

NovaDev currently requires an existing Python 3 installation with Tkinter. A
future native distribution can bundle a private Python runtime.
