# Mode Component Registry

NovaDev modes should not be simple names. Each mode should expose a component
and workflow vocabulary that the compiler can use.

The first registry lives in:

```txt
novadev/component_registry.py
```

Common components:

```txt
hero
section
form
table
card
calendar
gallery
cta
```

Mode components:

```txt
school:
  schoolNoticeBar
  schoolEventPanel
  departmentGrid
  admissionsForm

ecommerce:
  productGrid
  cartSummary
  orderTable

security:
  scanConsole
  findingTable
  riskCards

trading:
  strategyBoard
  signalFeed
  tradeJournal

gym:
  memberBoard
  invoiceBoard
  checkinLog
```

`mode custom` only gets common components and what the developer declares.

