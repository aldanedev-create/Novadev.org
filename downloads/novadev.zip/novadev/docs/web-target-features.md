# NovaDev Web Target Features

NovaDev now has a target feature registry for generated web applications.

This is the adjusted NovaDev approach:

```txt
Nova source
  -> normal language declarations
  -> ProjectIR features
  -> generated HTML5, Vue, Tailwind, Vite, and Flask support
```

## Syntax

Declare broad feature support:

```nova
features {
    html all
    vue router, pinia, forms, transitions, teleport, suspense, slots
    tailwind utilities, theme, responsive, darkMode, forms, typography
    vite devServer, proxy, env, aliases, plugins, pwa, build
    flask api, blueprints, sqlalchemy, migrations, cors, auth, sessions, uploads, mail, cache, limiter, jobs, testing
}
```

Declare one feature:

```nova
feature flask uploads
feature vite pwa
feature tailwind typography
```

## HTML5 Features

```txt
semantic
forms
media
canvas
svg
dialog
details
dragdrop
storage
pwa
accessibility
seo
```

## Vue Features

```txt
composition
router
pinia
forms
transitions
teleport
suspense
slots
directives
provideInject
i18n
```

## Tailwind Features

```txt
utilities
theme
responsive
darkMode
forms
typography
containerQueries
animation
print
```

## Vite Features

```txt
devServer
proxy
env
aliases
plugins
pwa
build
ssr
```

## Flask Features

```txt
api
blueprints
sqlalchemy
migrations
cors
auth
sessions
uploads
mail
cache
limiter
websockets
jobs
testing
```

## Generated Effects

NovaDev uses these features to generate:

- `index.html` meta tags, manifest link, icon, noscript, SEO hooks
- `vite.config.js` proxy, aliases, build options, optional PWA plugin
- `tailwind.config.js` plugins and dark mode settings
- `package.json` npm dependencies
- `requirements.txt` Python dependencies
- Flask auth/upload/job/cache/rate-limit/mail/websocket integration hooks
- ProjectIR feature metadata in `docs/project-ir.json`

## Why This Matters

The old approach produced similar projects because the generator did not know
what platform features the developer wanted.

The new approach lets NovaDev generate based on declared capability:

```txt
school site with PWA + uploads + mail
security scanner with websockets + limiter
analytics dashboard with charts + pandas
ecommerce app with auth + payments + cache
```

