# NovaDev Project Compiler

NovaDev is moving from a generic file generator to a real high-level app
compiler.

The goal is:

```txt
.nova source files
  -> smart ProjectIR
  -> project-specific Vue frontend
  -> project-specific Flask backend
  -> SQLite + SQLAlchemy data layer
  -> docs and tests
```

## Why This Exists

Older NovaDev generation created similar projects because the generator mostly
copied shared Vue and Flask structure. That was useful for prototypes, but it did
not prove that NovaDev could build the exact app a developer described.

The project compiler reads more project intent:

- mode
- theme
- tables
- pages
- page heroes
- sections
- forms
- tables
- workflows
- seeds
- layouts
- jobs
- tests
- assets
- auth hooks
- uploads
- email notifications
- jobs

Then it generates code from that intent.

## Fixed In The Project Compiler

The compiler now generates:

- physical `src/pages/<Page>.vue` artifacts for every declared `page`
- `src/generated/routes.js` with all declared routes
- school-specific section renderers for layouts such as `noticeBar`, `iconGrid`,
  `featureSplit`, `eventPanel`, `newsList`, `supportGrid`, and `peopleGrid`
- `backend/auth.py` with local register/login/token helpers
- `POST /api/uploads` and `/uploads/<filename>`
- workflow notification hooks through `Nova.email`
- `backend/jobs.py`, `GET /api/jobs`, and `POST /api/jobs/<name>/run`
- optional lightweight scheduler enabled with `NOVA_RUN_JOBS=true`

## Command

Use the project compiler with:

```bash
python nova.py build examples/apps/webshield_smart
```

or explicitly:

```bash
python nova.py build examples/apps/webshield_smart
```

Use the older generator only when needed:

```bash
python nova.py build examples/apps/webshield_smart --legacy
```

## High-Level Nova Syntax

### Project Mode

```nova
app WebShieldScanner {
    project {
        frontend Vue
        backend Flask
        database SQLite
        styling Tailwind
        mode security
    }
}
```

Modes change generation style and defaults:

```txt
school, ecommerce, security, trading, gym, restaurant, custom
```

`mode custom` is strict. It does not add domain assumptions.

### Tables

```nova
table Member {
    id auto
    name text required
    email email required
    balance money
}
```

Generated backend:

- SQLAlchemy table
- SQLite database table
- API resource
- form/table field metadata

### Workflows

```nova
workflow RegisterMember {
    input Member
    creates Member
    notify Admin
}
```

Generated backend:

```txt
POST /api/workflows/register-member
```

### Pages

```nova
page Dashboard {
    type dashboard

    hero {
        title "Gym Billing Pro"
        subtitle "Members, invoices, payments, and check-ins."
        action "Register Member" to "members"
    }

    card "Members" {
        value Member.count()
    }

    section Plans from Plan layout cards

    table Invoice {
        columns member, amount, dueDate, status
    }
}
```

Generated frontend:

- dashboard hero
- stat card
- API-backed record cards
- API-backed table

### Forms

```nova
page Members {
    type form

    form Member {
        fields name, email, plan, status, balance
        submit "Register Member"
        on submit RegisterMember
    }
}
```

Generated frontend:

```txt
Vue form -> POST /api/workflows/register-member -> SQLite row
```

### Seeds

```nova
seed Member {
    name "Aldane Example"
    email "aldane@example.com"
    plan "Premium"
    status "active"
    balance 0
}
```

Generated backend seeds the database when the table is empty.

### Jobs

```nova
job MonthlyBilling {
    schedule "monthly"
    run CreateInvoice
}
```

Jobs are stored in ProjectIR now. Future NovaDev releases should generate a real
job runner or scheduler.

### Tests

```nova
test BillingDashboard {
    expect Member.count() > 0
}
```

Tests are stored in ProjectIR now. The generated project also includes starter
Flask API tests.

## Examples

```txt
examples/apps/webshield_smart
examples/apps/cytro_trading_smart
examples/apps/gym_billing_smart
examples/apps/organic_wholesale_smart
examples/apps/church_media_custom_smart
examples/apps/analytics_dashboard_smart
```

## What This Fixes

The project compiler fixes the biggest limitation found in the school website
test:

```txt
NovaDev should not generate the same generic project every time.
```

Now the generated app changes based on:

- declared tables
- declared workflows
- declared pages
- declared mode
- declared seeds
- declared page components
- declared theme

## Current Limits

This is a compiler foundation, not the final NovaDev 2.0.

Current limits:

- Jobs are represented but not scheduled automatically yet.
- Tests are represented, with starter generated API tests.
- Advanced Nova algorithms still need the existing runtime or Python bridge.
- UI rendering uses a flexible generated Vue app instead of writing a unique Vue
  component file for every page.

The next step is to add a component registry where modes can generate more
specialized Vue components such as `SchoolNoticeBar`, `SecurityFindingTable`,
`TradingRiskPanel`, and `GymInvoiceBoard`.
