# NovaDev Complete Language Upgrade

NovaDev now uses one project compiler behind the project-building commands.

The compiler reads all `.nova` files in a project folder, builds a Project IR,
then generates editable full-stack code from the developer's declarations.

## Build Command

From the CLI:

```bash
python nova.py build-fullstack examples/apps/complete_language_upgrade -o generated
```

From the interactive shell:

```text
nova> .build-fullstack examples/apps/complete_language_upgrade -o generated
```

## What The Compiler Understands

- app/project configuration: frontend, backend, database, structure, styling, mode
- domain modes: custom, ecommerce, construction, crm, school, portfolio, restaurant,
  booking, dashboard, blog, cms, church, gym, inventory, delivery, realestate,
  healthcare, finance, trading, security, nonprofit, event, hotel, salon,
  learning, marketplace, social, forum, projectmanagement, invoice, pos,
  supportdesk, logistics
- page types: landing, marketing, catalog, product_detail, checkout, dashboard,
  admin, form, portfolio, profile, settings, report, calendar, booking, pipeline,
  table, custom
- tables, fields, workflows, pages, components, routes, jobs, seeds, tests, assets
- custom Python, JavaScript, and CSS blocks
- standard libraries such as `Nova.files`, `Nova.json`, `Nova.http`,
  `Nova.sqlite`, `Nova.math`, `Nova.crypto`, `Nova.email`, and data helpers

## Generated Frontend

NovaDev generates a Vue + Vite + Tailwind project with:

- `src/main.js`
- `src/App.vue`
- `src/router/index.js`
- `src/stores/appStore.js`
- `src/services/api.js`
- `src/layouts/DefaultLayout.vue`
- reusable components such as `DataTable`, `FormBuilder`, `StatCard`,
  `ChartBlock`, `HeroBlock`, `CatalogGrid`, and `WorkflowResult`
- generated page files under `src/pages/`
- custom JS/CSS modules under `src/custom/`
- Vite HMR, proxy, optimized build config, aliases, and Tailwind setup

## Generated Backend

For `backend Flask`, NovaDev generates:

- Flask app
- SQLAlchemy models
- SQLite database
- CRUD APIs
- workflow APIs
- explicit route stubs from `route METHOD "/api/path" { ... }`
- auth endpoints
- upload endpoints
- job endpoints
- `Nova` standard library wrapper
- custom Python modules under `backend/custom/`

For `backend Node`, `backend NodeJS`, or `backend Express`, NovaDev generates:

- Express server
- route module
- model/data module
- config module
- package.json
- explicit route stubs from Nova route declarations

## Custom Code

```nova
custom python pricing_tools {
    def apply_discount(total, percent):
        return round(float(total) * (1 - float(percent) / 100), 2)
}

custom js storefront_helpers {
    export function formatMoney(value) {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value || 0)
    }
}

custom css storefront_motion {
    .storefront-glow {
        box-shadow: 0 24px 80px rgba(245, 158, 11, 0.25);
    }
}
```

These become real generated files in the frontend/backend project.

## Command Rule

NovaDev is not a second compiler system anymore. `project_compiler.py` is the
single project compiler used by `.build`, `.build-fullstack`, `.build-mode`,
`build`, `build-fullstack`, and `build-mode`.

Use `.build-ui` when you only want the old standalone HTML/CSS/JS UI output.
Use `.build-backend` when you only want backend files.
Use `.build-app` when you want the older separate UI/backend outputs.
Use `.build-fullstack` or `.build-mode` when you want the upgraded Vue + Vite +
Tailwind + backend project compiler.
