# NovaDev Standard Library Direction

NovaDev needs a general-purpose side, not only an app generator. The standard
library foundation lives in:

```txt
novadev/standard_library.py
```

Planned Nova-facing modules:

```nova
use Nova.files
use Nova.json
use Nova.csv
use Nova.http
use Nova.sqlite
use Nova.math
use Nova.crypto
use Nova.env
use Nova.time
use Nova.dataframes
use Nova.arrays
use Nova.security
use Nova.trading
```

Examples:

```nova
let text = Nova.files.read("data/input.txt")
let rows = Nova.csv.read("members.csv")
let percent = Nova.math.percent(85, 100)
let apiKey = Nova.env.require("EXCHANGE_API_KEY")
let response = Nova.http.get("https://api.example.com/status")
```

This reduces the need for custom Python blocks. Python remains useful as a
bridge for advanced libraries, but normal app work should be possible in Nova.
