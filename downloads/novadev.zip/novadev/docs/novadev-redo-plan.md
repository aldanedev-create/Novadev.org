# NovaDev Compiler Redo

NovaDev now has one project-compilation pipeline:

```text
ModuleResolver -> lexer/parser -> AST -> ProjectIRBuilder -> ProjectIR
                                                      -> frontend target
                                                      -> backend target
                                                      -> docs and tests
```

## Completed Consolidation

- `NovaProjectReader` and its raw-source regular-expression parsing were
  removed.
- High-level declarations such as layouts, seeds, jobs, tests, packages,
  features, relationships, page layouts, form workflows, and role rules are
  structured AST data.
- `project_ir.py` owns the canonical ProjectIR classes. Compiler compatibility
  names are aliases, not a second model.
- The obsolete `project_generator.py` orchestrator was removed.
- UI, backend, app, Vue, full-stack, and mode builds load the same ProjectIR.
- `nova_modules.py` was merged into `standard_library.py`.
- `semantic_analyzer.py` was merged into `semantic.py`, retaining structural
  checks and hardcoded-secret/unsafe-code scanning.
- Generated Flask apps vendor `nova_libs.py` and run without NovaDev installed.
- `frontend Vue` now means a pinned Vue 3 CDN module with no npm frontend
  build; `frontend VueVite` remains an explicit separate target.
- Flask output uses an application factory and API/web blueprints. Express
  output uses Node's built-in SQLite API. Both share the same ProjectIR access,
  workflow, auth, and project metadata.
- Authentication uses declared SQLite account tables when available. Passwords
  are hashed, secure fields are redacted, and browser metadata excludes seeds
  and local source paths.

## Acceptance Record

- All 23 maintained projects under `examples/apps/` build through this
  compiler.
- 343 generated Python files pass `py_compile`.
- 78 generated JavaScript files pass `node --check`.
- Flask + HTML, Vue CDN + Flask, and Vue CDN + Express pass health, frontend,
  seeded-login, role-policy, persistence, and credential-redaction probes.

## Forward Rule

Every new language feature must be implemented in this order:

1. Add or extend lexer/parser/AST support.
2. Map the AST node into canonical ProjectIR.
3. Emit behavior in each relevant target.
4. Extend the single semantic analyzer.
5. Add a `.nova` example and regression test.

Do not add another source reader, ProjectIR family, semantic analyzer, or
orchestrator. A genuinely different output target can have its own emitter, but
it must consume the same ProjectIR.
