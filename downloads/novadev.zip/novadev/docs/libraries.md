# NovaDev Libraries

NovaDev libraries let developers use high-level APIs from `.nova` without
dropping into raw Python for normal work.

The goal:

```txt
Nova code
  -> use Nova library
  -> compiler adds pip/npm dependencies
  -> generated backend/frontend exposes the capability
```

## Built-In Libraries

```nova
use Nova.files
use Nova.json
use Nova.csv
use Nova.http
use Nova.sqlite
use Nova.math
use Nova.stats
use Nova.crypto
use Nova.env
use Nova.time
```

Example:

```nova
use Nova.files
use Nova.json

let data = {
    name: "NovaDev",
    mode: "app language"
}

Nova.files.write("report.json", Nova.json.stringify(data))
print(Nova.files.read("report.json"))
```

## Higher-Level Python-Backed Libraries

These libraries wrap common Python packages with beginner-friendly Nova names.

```nova
use Nova.dataframes   # pandas
use Nova.arrays       # numpy
use Nova.excel        # pandas + openpyxl
use Nova.pdf          # pypdf + reportlab
use Nova.scraper      # requests + beautifulsoup4
use Nova.security     # web checks
use Nova.trading      # trading calculations
use Nova.ml           # scikit-learn helpers
```

Example with pandas-style data:

```nova
use Nova.dataframes

let sales = Nova.dataframes.readCsv("sales.csv")
let total = sales.sum("amount")
let byCategory = sales.groupBy("category").sum("amount")

print(total)
print(byCategory)
```

NovaDev adds this to generated `requirements.txt`:

```txt
pandas>=2.2,<3.0
```

## Frontend Libraries

```nova
use Nova.charts
use Nova.maps
use Nova.three
```

NovaDev adds npm dependencies:

```txt
chart.js
vue-chartjs
leaflet
three
```

## Package Declarations

Use `package` when a project requires a direct dependency:

```nova
package pandas {
    provider python
    version ">=2.2,<3.0"
    target backend
}
```

Use `use Nova.dataframes` when you want the higher-level Nova wrapper.

## Python Bridge Still Exists

For advanced custom logic:

```nova
module ReportTools python {
    requires pandas
    export monthlyReport

    python """
import pandas as pd

def monthlyReport(path):
    df = pd.read_csv(path)
    return df.groupby("month")["amount"].sum().to_dict()
"""
}
```

The long-term rule:

```txt
Use Nova libraries first.
Use Python bridge only when the Nova API is not enough.
```

