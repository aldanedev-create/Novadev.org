# Effective Web Applications With NovaDev

NovaDev compiles project intent into normal editable web applications. The
compiler follows one path:

```text
.nova modules -> lexer -> parser -> AST -> ProjectIR -> selected generators
```

No web generator reads Nova source with regular expressions. Imported `.nova`
files are resolved once, parsed once, and merged into the same AST.

## Three Application Methods

### Flask With HTML, CSS, And Vanilla JavaScript

```nova
app CompanySite {
    project {
        frontend HTML
        backend Flask
        database SQLite
        mode custom
    }
}
```

This target generates semantic HTML, local CSS, browser JavaScript, a Flask
application factory, API and web blueprints, SQLAlchemy storage, and tests.

### Vue CDN With Node/Express

```nova
app TeamBoard {
    project {
        frontend Vue
        backend Express
        database SQLite
        mode dashboard
    }
}
```

`frontend Vue` means Vue 3 loaded from a pinned production CDN module. The
frontend is split into `index.html`, `app.js`, `components.js`, `project.js`,
and `style.css`. There is no frontend package installation or build step. The
Express backend remains a normal Node application.

The generated Express target requires Node.js 22.5 or newer and uses the
built-in `node:sqlite` API. This avoids a native SQLite package installation
while keeping real file-backed persistence.

### Vue CDN With Flask

```nova
app SchoolPortal {
    project {
        frontend Vue
        backend Flask
        database SQLite
        mode school
    }
}
```

Flask serves the generated CDN Vue files and the JSON API from one process.
This is the default split used by `frontend Vue` plus `backend Flask`.

Use `frontend VueVite` only when the application specifically needs Vite,
single-file `.vue` components, Pinia packages, or a bundled production build.
Vue's official documentation notes that CDN Vue has no build step and does not
support SFC syntax, so NovaDev emits ordinary JavaScript component modules for
the CDN target.

For `styling Tailwind`, the CDN target emits local project-specific CSS rather
than loading Tailwind's Play CDN in production. Use `frontend VueVite` when the
developer needs Tailwind's package plugin, arbitrary utility compilation, or
third-party Tailwind plugins.

## Project Intent

```nova
page Admin {
    type admin
    require auth
    role Admin
}

table Student {
    id auto
    name text required
    email email unique required
}

workflow RegisterStudent {
    input Student
    creates Student
    validates name, email
}
```

The AST-to-ProjectIR builder infers baseline capabilities from these
declarations. Tables imply database/API support. Protected pages imply auth and
sessions. Relations imply migrations. A `features {}` block is for an explicit
addition or override, not boilerplate every project must repeat.

## Vue CDN Output

Generated CDN Vue applications use:

- a pinned Vue 3 production ESM URL;
- reactive state, computed page selection, event handling, forms, and lists;
- separate reusable JavaScript component definitions;
- hash-based page navigation with no router package requirement;
- API-backed records generated from page component sources;
- frontend access gates plus bearer tokens for protected API resources;
- local project-specific CSS and theme variables;
- no `innerHTML` in generated Vue code.

Declared `section`, `catalog`, `table`, `form`, `card`, `chart`, `button`, and
hero blocks become working UI behavior. The generated files stay readable to a
Vue developer who has never used NovaDev.

## Flask Output

Generated Flask projects follow the scalable structure described in practical
Flask application design:

```text
backend/
  app.py
  wsgi.py
  config.py
  models.py
  auth.py
  jobs.py
  nova_libs.py
  application/
    __init__.py
    api.py
    web.py
    security.py
    extensions.py
```

`application.create_app()` creates and configures each Flask instance. API and
frontend routes are blueprints. Development, testing, and production
configuration are separate. Optional extensions are created without binding to
a global app and initialized inside the factory.

The backend provides SQLite/SQLAlchemy tables, seed insertion, CRUD endpoints,
workflow endpoints, generated auth, uploads, jobs, security headers, payload
sanitization, and rate limiting. Passwords use Werkzeug's salted `scrypt`
hashing, tokens expire, public self-registration roles are restricted, and
protected resources enforce roles on the server.

When a declared table contains `email` plus a `secure`/`password` field, it
becomes the authentication store. Seeded and registered passwords are hashed in
the generated SQLite database. Secure fields are removed from CRUD responses,
credential tables default to admin-only access, and frontend/project metadata
never includes seed passwords or host filesystem paths.

## Frontend And Backend Contract

```text
GET    /api/<resource>
POST   /api/<resource>
PATCH  /api/<resource>/<id>
DELETE /api/<resource>/<id>
POST   /api/workflows/<workflow>
GET    /api/schema
GET    /api/health
POST   /api/auth/login
```

Example:

```nova
form AdmissionInquiry {
    fields student_name, parent_name, email, phone, grade, message
    submit "Send Inquiry"
    on submit SubmitAdmissionInquiry
}
```

The generated Vue form calls
`POST /api/workflows/submit-admission-inquiry`. The Flask workflow stores rows
in the declared SQLite table and can invoke a notification hook.

## Access Control

```nova
page StudentLife {
    require auth
    role Student
}

page Admin {
    require auth
    role Admin
}
```

The frontend hides protected page content until login. The backend independently
checks bearer tokens and roles for resources used only by protected pages.
Resources intentionally displayed on a public section remain publicly readable.

## Build Commands

All commands use the same compiler and ProjectIR:

```text
.build-ui <project> -o dist
.build-backend <project> -o generated_backend --frontend dist
.build-app <project> --ui-output dist --backend-output generated_backend
.build-vue <project> -o frontend
.build-fullstack <project> -o generated
.build-mode <project> -o generated
```

For a Vue CDN plus Flask project:

```bash
python shell.py .build-fullstack my_project -o generated
cd generated/my-project/backend
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`. No frontend npm command is needed.

## Complete Target Examples

- `examples/apps/web_targets/flask_html`: Flask + HTML/CSS/vanilla JavaScript.
- `examples/apps/web_targets/vue_express`: Vue CDN + Express + SQLite.
- `examples/apps/web_targets/vue_flask`: Vue CDN + Flask + SQLAlchemy/SQLite.

Each example includes working pages, forms, workflows, seeded data,
authentication, role checks, and project-specific styling.

## Security And Deployment

Security defaults reduce common mistakes but do not make generated code immune
to attack. Production deployments must set `NOVA_SECRET_KEY`, configure exact
CORS origins, use HTTPS, configure durable rate-limit/cache storage when those
extensions are selected, review permissions, run tests, and use a production
WSGI server.

Generated backends are standalone. `nova_libs.py` is vendored into the output
and never imports the NovaDev compiler package.
