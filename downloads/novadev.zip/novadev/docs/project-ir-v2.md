# ProjectIR v2 Direction

NovaDev now has two generation layers:

```txt
Legacy ProjectIR
  Used by the older template-style generator.

Smart ProjectIR
  Built by novadev/project_compiler.py.
  Used by the project-specific compiler.
```

The project compiler IR contains:

```txt
app name
mode
frontend/backend/database/styling targets
theme
tables
fields
relationships
pages
heroes
components
workflows
layouts
seeds
jobs
tests
assets
available mode components
source file list
```

The generated project writes this IR to:

```txt
generated/<app>/docs/project-ir.json
```

Future work should merge the legacy and smart IR into one compiler pipeline:

```txt
lexer -> parser -> AST -> semantic analyzer -> ProjectIR v2 -> generators
```
