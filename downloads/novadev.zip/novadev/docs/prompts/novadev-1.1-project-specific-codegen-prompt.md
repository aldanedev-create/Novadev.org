# NovaDev 1.1 Project-Specific Code Generation Prompt

Use this prompt to implement NovaDev 1.1.

```text
Build NovaDev 1.1: Project-Specific Code Generation.

Goal:
NovaDev must become a real project compiler, not a generic template copier.
Each `.nova` app must generate code based on its mode, pages, workflows,
entities/tables, routes, custom modules, and developer-written code.

Current problem to fix:
Generated apps currently share too much generic code. An e-commerce app, a
construction website, a CRM, and a custom app can all receive similar Vue pages,
stores, backend routes, and components even when that code does not fit the
project. NovaDev 1.1 must stop generating unrelated code.

New compiler pipeline:

.nova source
  -> lexer
  -> parser
  -> AST
  -> semantic analyzer
  -> ProjectIR
  -> domain/mode generator
  -> project-specific frontend/backend/database/docs

Important:
- Keep Python 3 only for the NovaDev compiler.
- Generated projects may use Vue, Flask, HTML, CSS, JavaScript, and SQLite.
- No AI is required at runtime.
- AI can be optional later, but the compiler must work deterministically.
- Keep code beginner-friendly and heavily documented.

1. Add ProjectIR

Create a real internal project model after AST parsing.

Add files such as:

- novadev/project_ir.py
- novadev/project_ir_builder.py
- novadev/domain_registry.py
- novadev/workflow_ir.py
- novadev/module_ir.py
- novadev/generators/

ProjectIR should include:

- app name
- mode
- stack/frontend/backend/database
- entities/tables
- fields
- pages
- page types
- components
- workflows
- routes
- auth
- themes
- plugins
- architecture entries
- custom frontend code
- custom backend code
- custom database code
- Nova-wrapped Python modules
- JavaScript modules
- CSS modules
- source file ownership
- generated file plan

Example Python shape:

ProjectIR(
    name="BuildRightConstruction",
    mode="construction",
    frontend="Vue",
    backend="Flask",
    database="SQLite",
    entities=[...],
    pages=[...],
    workflows=[...],
    modules=[...],
    custom_code=[...]
)

AST means:
What did the developer write?

ProjectIR means:
What does this project need?

2. Add many common modes

NovaDev must support common category modes. Each mode should provide useful
defaults, validation, page suggestions, workflow generators, and code generation
behavior.

Required modes:

- custom
- ecommerce
- construction
- crm
- school
- portfolio
- restaurant
- booking
- dashboard
- blog
- cms
- church
- gym
- inventory
- delivery
- realestate
- healthcare
- finance
- trading
- security
- nonprofit
- event
- hotel
- salon
- learning
- marketplace
- social
- forum
- projectmanagement
- invoice
- pos
- supportdesk
- logistics

Each mode must define:

- expected entities
- optional entities
- common workflows
- common pages
- useful frontend components
- useful backend routes
- domain-specific validation warnings
- starter seed data appropriate to that mode

Examples:

mode ecommerce:
- entities: Product, Customer, CartItem, Order, OrderItem, Review, Coupon
- workflows: AddToCart, Checkout, ApplyCoupon, UpdateStock, OrderStatus
- pages: StoreFront, ProductDetails, Cart, Checkout, Orders, AdminDashboard

mode construction:
- entities: Service, Project, Lead, Estimate, TeamMember, Testimonial
- workflows: LeadCapture, EstimateRequest, ProjectStatusUpdate
- pages: Home, Services, Projects, Contact, Quote, AdminDashboard

mode crm:
- entities: Client, Contact, Deal, Task, Note, PipelineStage
- workflows: CreateLead, MoveDealStage, ScheduleFollowUp, CloseDeal
- pages: Dashboard, Clients, Deals, Pipeline, Tasks

mode school:
- entities: Student, Teacher, Course, Grade, Attendance, Assignment
- workflows: EnrollStudent, RecordGrade, MarkAttendance
- pages: Dashboard, Students, Courses, Grades, Attendance

mode church:
- entities: Sermon, PrayerRequest, Event, Member, Donation, Ministry
- workflows: SubmitPrayer, PublishSermon, RegisterEvent, RecordDonation
- pages: Home, Sermons, Prayer, Events, Giving, Admin

mode gym:
- entities: Member, Plan, Trainer, Workout, Invoice, Attendance
- workflows: RegisterMember, BillMember, CheckIn, AssignTrainer
- pages: Dashboard, Members, Billing, Trainers, Classes

mode security:
- entities: Scan, Finding, Target, Report, User
- workflows: RunScan, GenerateReport, AssignFinding, ResolveFinding
- pages: Dashboard, Targets, Scans, Findings, Reports

3. Define mode custom

`mode custom` means NovaDev must not assume a domain.

Example:

app MyProject {
    mode custom
}

Behavior:

- Do not add e-commerce defaults.
- Do not add construction defaults.
- Do not add CRM defaults.
- Do not invent domain pages.
- Do not generate unrelated workflows.
- Only generate from what the developer explicitly declares.

mode custom should generate code from:

- declared tables/entities
- declared pages
- declared workflows
- declared routes
- declared modules
- declared architecture
- declared custom frontend/backend/database code
- declared Python/JS/CSS/SQL files

Example custom app:

app ChurchMediaSystem {
    mode custom

    table Sermon {
        id auto
        title text
        speaker text
        videoUrl text
        date date
    }

    table PrayerRequest {
        id auto
        name text
        message text
        status text
    }

    workflow SubmitPrayer {
        input PrayerRequest
        creates PrayerRequest
        notify Admin
    }

    page Home {
        type landing
        section Sermons from Sermon
        form PrayerRequest
    }

    page Admin {
        type dashboard
        table Sermon
        table PrayerRequest
    }
}

The generated app must only contain sermon/prayer/admin code. It must not
contain cart, checkout, construction estimator, school grades, CRM deals, etc.

4. Add richer language syntax

Add syntax for:

workflow:

workflow Checkout {
    input CartItem
    creates Order
    clears CartItem
    validates stock
    uses Pricing.calculateTotal
}

workflow EstimateRequest {
    input Lead
    uses ConstructionEstimator.estimate
    creates Estimate
    creates Lead
    notify Admin
}

page type:

page Home {
    type marketing

    hero {
        title "Reliable construction services"
        subtitle "Homes, commercial spaces, roofing, and repairs"
        action "Request Quote" to "/quote"
    }

    section Services from Service
    section Projects from Project
    section Testimonials from Testimonial
}

module:

module ConstructionEstimator python {
    export estimate

    python """
def estimate(square_feet, project_type, finish):
    base = {
        "residential": 118,
        "commercial": 165,
        "roofing": 74
    }.get(str(project_type).lower(), 100)

    finish_multiplier = {
        "basic": 0.88,
        "standard": 1.0,
        "premium": 1.22
    }.get(str(finish).lower(), 1.0)

    return round(float(square_feet) * base * finish_multiplier, 2)
"""
}

module CartMath python {
    export calculate_total

    python """
def calculate_total(items):
    return sum(float(item.get("price", 0)) * int(item.get("quantity", 1)) for item in items)
"""
}

module StoreFront js {
    export addToCart

    js """
export function addToCart(cart, product) {
  return [...cart, product]
}
"""
}

Named custom code:

custom frontend CartToast {
    js """
export function showCartToast(message) {
  console.log(message)
}
"""
}

custom css StoreTheme {
    """
.storefront {
  background: #f8fafc;
}
"""
}

custom backend PricingTools {
    python """
def discount(price, percent):
    return price * (1 - percent / 100)
"""
}

Generated filenames must be meaningful:

- frontend/src/features/cart/CartToast.js
- frontend/src/styles/StoreTheme.css
- backend/modules/PricingTools.py
- backend/modules/ConstructionEstimator.py

Avoid random names like custom_1.py when a developer provides a name.

5. Nova-wrapped Python modules must work

This is required.

NovaDev must support Python modules wrapped in Nova source and use them in
generated backends and workflows.

Required behavior:

- Parse `module Name python { ... }`
- Store it in AST
- Add it to ProjectIR
- Write it to generated backend module files
- Validate Python syntax with `py_compile`
- Import it in generated Flask workflow/routes when used
- Expose exported functions to generated workflow code
- Block unsafe Python by default
- Allow only safe modules unless `allow unsafe_python true`
- Produce clear errors for invalid Python code
- Produce clear errors when a workflow uses a missing module or missing function

Example:

module ConstructionEstimator python {
    export estimate

    python """
def estimate(square_feet, project_type, finish):
    return round(float(square_feet) * 120, 2)
"""
}

workflow EstimateRequest {
    input Lead
    uses ConstructionEstimator.estimate
    creates Estimate
}

Generated backend should include:

backend/modules/construction_estimator.py
backend/workflows/estimate_request.py

The workflow route should import and call:

from modules.construction_estimator import estimate

Do not just write the file and ignore it. The wrapped module must be connected
to generated workflow code.

6. Add ProjectIR validation

Semantic analyzer must check:

- missing workflow input table
- missing created table
- missing module
- missing exported function
- page section references unknown table
- mode custom has no declared pages
- mode custom has no declared entities/tables
- domain mode is missing recommended entities
- duplicate route paths
- duplicate generated file paths
- unsafe Python usage without permission
- invalid Python module syntax
- invalid JavaScript syntax if Node is available

Warnings should be beginner-friendly.

Example:

warning: mode ecommerce usually needs Product and Order tables
error: workflow Checkout uses missing module CartMath.calculate_total
error: page Home section Services references unknown table Service

7. Add specific code generators

Do not use one generic page for every project.

Create domain-aware generators:

generators/
  project_ir_builder.py
  domain_registry.py
  frontend/
    vue/
      vue_project_generator.py
      pages/
        marketing_page.py
        catalog_page.py
        checkout_page.py
        dashboard_page.py
        portfolio_page.py
        form_page.py
        report_page.py
      features/
        cart_feature.py
        lead_capture_feature.py
        estimate_feature.py
        booking_feature.py
        pipeline_feature.py
        attendance_feature.py
  backend/
    flask/
      flask_project_generator.py
      crud_generator.py
      workflow_generator.py
      module_generator.py
      route_generator.py
      seed_generator.py

Generation rules:

- mode ecommerce + workflow Checkout generates cart/checkout code
- mode construction + workflow EstimateRequest generates estimator code
- mode crm + workflow MoveDealStage generates pipeline code
- mode school + workflow MarkAttendance generates attendance code
- mode custom generates only declared pages/workflows/routes/modules

8. Add page type generation

Supported page types:

- landing
- marketing
- catalog
- product_detail
- checkout
- dashboard
- admin
- form
- portfolio
- profile
- settings
- report
- calendar
- booking
- pipeline
- table
- custom

Each page type should generate different Vue code.

Example:

page Home type marketing:
- hero
- sections
- CTA
- responsive layout

page StoreFront type catalog:
- product grid
- filters
- cart interaction if workflow exists

page Quote type form:
- form fields
- validation
- submit route

page Admin type dashboard:
- stat cards
- tables
- charts

9. Add generated docs

Each generated project must include:

- docs/project-ir.json
- docs/mode.md
- docs/workflows.md
- docs/modules.md
- docs/generated-files.md
- docs/custom-code.md

For mode custom, docs must explicitly say:

This project uses `mode custom`, so NovaDev generated only declared entities,
pages, workflows, routes, modules, and custom code. No domain defaults were
added.

10. Update CLI

Add or update:

python nova.py ir path/to/project
python nova.py explain path/to/project
python nova.py validate path/to/project
python nova.py build-fullstack path/to/project
python nova.py build-mode path/to/project

`ir` prints ProjectIR as JSON.
`explain` explains why files were generated.
`validate` runs semantic checks, Python module checks, JS checks if available,
and generated backend compile checks.

11. Update shell

Shell must support:

.ir examples/apps/store
.explain examples/apps/store
.validate examples/apps/store
.build-fullstack examples/apps/store

Normal NovaDev programming code must still run in shell.

12. Examples required

Create examples:

examples/apps/ecommerce_1_1/
examples/apps/construction_1_1/
examples/apps/crm_1_1/
examples/apps/school_1_1/
examples/apps/church_custom_1_1/
examples/apps/gym_custom_1_1/
examples/apps/security_1_1/
examples/apps/booking_1_1/

Each example must:

- use multiple `.nova` files
- use imports
- declare mode
- declare workflows
- declare page types
- use at least one custom module
- include at least one Nova-wrapped Python module where useful
- build successfully
- validate successfully

13. Tests required

Add tests or smoke scripts that verify:

- ProjectIR builds for each example
- mode custom does not add unrelated domain defaults
- ecommerce produces cart/checkout code only when declared or domain default is appropriate
- construction produces estimator code only when workflow/module declares it
- Python modules wrapped in Nova are written to backend modules
- Python modules compile with py_compile
- workflows import and call exported Python functions
- missing module/function gives clear error
- generated Flask backend compiles
- generated API routes return 200 with Flask test client
- custom JS syntax is checked if Node is available

14. Documentation required

Update README.md and docs:

- docs/project-ir.md
- docs/modes.md
- docs/mode-custom.md
- docs/workflows.md
- docs/page-types.md
- docs/modules.md
- docs/python-modules.md
- docs/project-specific-generation.md
- docs/examples-1.1.md

Docs must explain:

- how modes work
- what `mode custom` does
- how workflows create specific code
- how Python modules wrapped in Nova work
- how to inspect ProjectIR
- how to validate generated projects
- why NovaDev 1.1 avoids generic unrelated code

15. Quality bar

The final implementation must:

- keep existing NovaDev 1.0 examples working
- not remove existing CLI commands
- use deterministic code generation
- not rely on AI to build
- generate project-specific code
- avoid unrelated generated code
- produce clear errors
- verify Python modules wrapped in Nova
- make common categories rich enough to be useful
- keep beginner-friendly comments and docs

End goal:
NovaDev 1.1 should let a developer write a meaningful `.nova` project and get
specific generated code for that project. An e-commerce app should feel like an
e-commerce app. A construction website should feel like a construction website.
A CRM should feel like a CRM. A `mode custom` project should contain only what
the developer declared.
```
