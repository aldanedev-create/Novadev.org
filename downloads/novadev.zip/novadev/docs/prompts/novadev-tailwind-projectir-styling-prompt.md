# NovaDev Tailwind + ProjectIR Styling Implementation Prompt

Implement Tailwind CSS as a first-class NovaDev project styling target.

## Goal

NovaDev should generate Vue projects that are visually shaped by ProjectIR, not
by one shared `main.css` that makes every app look the same.

The generated UI should still use normal reusable framework code, but the visual
identity must come from:

- `project { styling Tailwind }`
- `project { mode ... }`
- declared `theme` blocks
- declared page types
- declared page components
- declared entities/workflows

## Language Syntax

Support this project setting:

```nova
app MyApp {
    project {
        frontend Vue
        backend Flask
        styling Tailwind
        mode ecommerce
    }
}
```

Also allow themes to override styling tokens:

```nova
theme FreshStore {
    primary "#f59e0b"
    accent "#111827"
    surface "#fff7ed"
    radius "small"
    density "compact"
}
```

## ProjectIR

ProjectIR must include styling information:

```json
{
  "styling": "Tailwind",
  "style": {
    "system": "Tailwind",
    "mode": "ecommerce",
    "primary": "#f59e0b",
    "accent": "#111827",
    "surface": "#fff7ed",
    "radius": "small",
    "density": "compact",
    "shell": "...",
    "hero": "...",
    "panel": "..."
  }
}
```

## Mode Profiles

Add ProjectIR-driven Tailwind profiles for:

```txt
custom, ecommerce, construction, crm, school, portfolio, restaurant, booking,
dashboard, blog, cms, church, gym, inventory, delivery, realestate, healthcare,
finance, trading, security, nonprofit, event, hotel, salon, learning,
marketplace, social, forum, projectmanagement, invoice, pos, supportdesk,
logistics
```

Each mode should define enough tokens/classes to make generated projects look
different:

- primary color
- accent color
- surface color
- text color
- hero treatment
- shell/sidebar treatment
- panel/card treatment
- button treatment
- density
- radius

## Vue Generation

When styling is Tailwind:

- write `tailwind.config.js`
- add Tailwind and `@tailwindcss/vite` dev dependencies to `package.json`
- configure the Tailwind Vite plugin
- write `src/assets/main.css` using `@import "tailwindcss"`, `@theme`, and generated CSS vars
- emit Vue components with Tailwind utility classes from ProjectIR style profile
- avoid one huge fixed visual CSS file

The shared CSS should only contain Tailwind setup, CSS variables, and tiny base
rules. Most project-specific style should be expressed through generated
Tailwind classes.

## Default Behavior

For Vue projects, Tailwind should be the preferred generated styling system.
Developers can still request plain CSS:

```nova
project {
    styling CSS
}
```

## General-Purpose Language Example

Add an example that uses NovaDev's normal programming side to generate/write
project declarations or project data. The example should show that NovaDev is
not only a DSL; it can use variables, loops, functions, lists, objects, and
print logic to help developers build projects.

## Acceptance Checks

Run:

```bash
python -m py_compile novadev/ast_nodes.py novadev/project_ir.py novadev/project_ir_builder.py novadev/styling_registry.py novadev/vue_generator.py
python nova.py ir examples/apps/ecommerce_1_1
python nova.py build-fullstack examples/apps/ecommerce_1_1
python nova.py build-fullstack examples/apps/construction_1_1
python nova.py build-fullstack examples/apps/church_custom_1_1
```

Inspect generated projects:

- Vue package includes Tailwind deps.
- Vue project includes `tailwind.config.js`.
- `vite.config.js` includes the Tailwind Vite plugin.
- `main.css` is Tailwind-based.
- ecommerce, construction, and church/custom generated Vue files use different
  style profile classes.
- `mode custom` still does not inherit ecommerce/construction behavior.
