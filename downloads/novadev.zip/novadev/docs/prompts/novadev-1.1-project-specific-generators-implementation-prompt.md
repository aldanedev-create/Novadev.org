# NovaDev 1.1 Project-Specific Generator Implementation Prompt

Build NovaDev so it behaves more like a real project compiler and less like a repeated template copier.

## Goal

When a developer writes a `.nova` project, NovaDev must generate shared framework code only where framework code is expected, then generate project-specific frontend, backend, workflow, module, and documentation code from the developer's declarations.

Shared code is acceptable for:

- Vue app bootstrap
- Vue Router setup
- Pinia store setup
- Flask app bootstrap
- generic CRUD helpers
- API fetch helpers
- layout components

Project-specific code must come from:

- `app mode`
- declared tables/entities
- declared pages and page types
- declared page components
- declared workflows
- declared Python/JS/CSS modules
- declared custom frontend/backend code
- declared architecture/filesystem blocks

## Required Behavior

### `mode custom`

`mode custom` means:

```txt
Do not infer ecommerce, construction, CRM, school, or any other domain.
Generate only what the developer explicitly declared.
```

NovaDev must not add checkout, cart, estimator, lead forms, pipeline boards, school attendance, or any other domain behavior unless the `.nova` source declares those concepts.

### common modes

Common modes may provide domain-aware rendering only when the project also declares matching entities/pages/workflows.

Examples:

- `mode ecommerce` may render catalog/cart/checkout behavior when the project declares `Product`, `CartItem`, `Order`, catalog components, checkout pages, or checkout workflows.
- `mode construction` may render marketing/estimator/lead behavior when the project declares services, projects, lead/estimate workflows, or estimator components.
- `mode crm` may render a pipeline board when the project declares deals/stages or a pipeline page.

The compiler must not blindly add unrelated behavior just because the mode name exists.

## Frontend Generation

Generate Vue pages from ProjectIR:

- landing/marketing pages should render declared hero blocks and declared sections
- catalog pages should render declared catalog fields and add-to-cart actions only when cart entities exist
- checkout pages should call declared checkout workflows when present
- form pages should call a workflow matching the form input entity when present, otherwise fall back to generic create-row
- dashboard pages should render cards/tables/charts from declared components
- pipeline pages should render deal-like records grouped by stage when declared
- custom pages should render only declared components

Generated Vue code should include project-specific constants describing the actual tables, pages, workflows, and mode.

## Backend Generation

Generated Flask code should:

- always include normal CRUD endpoints for declared tables
- always include declared routes
- include workflow endpoints for declared workflows
- call wrapped Python modules from workflow `uses Module.function`
- create declared workflow entities
- avoid hard-coded ecommerce-only routes in non-ecommerce apps

Special convenience routes such as `/api/checkout` are allowed only when ProjectIR proves that the project declared ecommerce checkout behavior.

## Documentation

Generated project docs should explain:

- why each project mode was selected
- which entities were generated
- which pages were generated
- which workflows were generated
- which custom modules were copied
- which routes and workflow endpoints exist

## Acceptance Tests

Run these checks:

```bash
python nova.py validate examples/apps/ecommerce_1_1
python nova.py validate examples/apps/construction_1_1
python nova.py validate examples/apps/church_custom_1_1
python nova.py build-fullstack examples/apps/ecommerce_1_1
python nova.py build-fullstack examples/apps/construction_1_1
python nova.py build-fullstack examples/apps/church_custom_1_1
python -m py_compile novadev/vue_generator.py novadev/codegen.py novadev/project_generator.py
```

Then inspect generated code:

- Ecommerce may contain cart/checkout behavior.
- Construction may contain estimator/lead behavior.
- Church custom must not contain checkout/cart/ecommerce behavior unless declared.
