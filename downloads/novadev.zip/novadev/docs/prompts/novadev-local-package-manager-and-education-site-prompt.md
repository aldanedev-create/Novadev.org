# NovaDev Local Package Manager + Education Website Prompt

Build a local NovaDev package manager and a static education website.

## Goal

NovaDev should be easy for developers to get onto their system and learn.

The user plans to host a mostly frontend website on Vercel. The website should
teach NovaDev and provide download/install instructions for a local package
manager. Developers download the package manager first, then use it to install
NovaDev locally.

## Package Manager

Create a Python 3 only package manager named `novapm`.

It must work locally without external libraries.

Commands:

```bash
python novapm.py install-language --source .
python novapm.py doctor
python novapm.py list
python novapm.py search ui
python novapm.py install packages/hello-ui
python novapm.py remove hello-ui
python novapm.py info hello-ui
python novapm.py init-registry
python novapm.py configure-registry https://example.com/nova-packages.json
```

Local install layout:

```txt
~/.novadev/
  bin/
  language/
  packages/
  cache/
  registry.json
  installed.json
  config.json
```

The package manager should:

- install/copy the NovaDev language into `~/.novadev/language`
- create launcher scripts in `~/.novadev/bin`
- install packages from local folders, zip files, or registry URLs
- track installed packages in `installed.json`
- search package metadata from the configured registry
- print clear PATH instructions instead of editing PATH automatically
- avoid destructive filesystem operations outside `~/.novadev`

Package manifest:

```json
{
  "name": "hello-ui",
  "version": "0.1.0",
  "description": "Example NovaDev UI components",
  "entry": "index.nova",
  "kind": "module",
  "files": ["index.nova"]
}
```

## Education Website

Create a folder:

```txt
nova website/
```

The site must be static and Vercel-ready.

Files:

```txt
nova website/
  index.html
  styles.css
  app.js
  vercel.json
  README.md
  downloads/
    install-novadev.py
```

Website content:

- what NovaDev is
- how to install with `novapm`
- how the language works: lexer, parser, AST, runtime, ProjectIR
- general-purpose programming examples
- full-stack app examples
- Tailwind/Vue/Flask generation
- mode custom vs mode ecommerce/construction/etc.
- package manager commands
- beginner learning path

The website should feel like a developer education site, not a marketing-only
landing page. The first screen should immediately teach/install, not only sell.

## Acceptance Checks

Run:

```bash
python -m py_compile novadev/package_manager.py novapm.py
python novapm.py --help
python novapm.py init-registry --home .tmp-novapm-home
python novapm.py install packages/hello-ui --home .tmp-novapm-home
python novapm.py list --home .tmp-novapm-home
python novapm.py remove hello-ui --home .tmp-novapm-home
```

Inspect:

- `nova website/index.html`
- `nova website/styles.css`
- `nova website/app.js`
- `nova website/downloads/install-novadev.py`
