from __future__ import annotations

"""Remove a portable NovaDev installation while preserving user projects."""

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def normalize_path(value: str | Path) -> str:
    return os.path.normcase(os.path.normpath(str(Path(value).expanduser())))


def validate_install_home(value: str | Path) -> Path:
    home = Path(value).expanduser().resolve()
    language = home / "language"
    if home in {Path.home().resolve(), Path(home.anchor)}:
        raise ValueError("Refusing to uninstall from a home or filesystem root directory")
    if not (language / "nova.py").exists() or not (home / "bin").exists():
        raise ValueError(f"This does not look like a NovaDev installation: {home}")
    return home


def remove_from_user_path(bin_dir: Path) -> None:
    if os.name != "nt":
        return
    import ctypes
    import winreg

    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE) as key:
        try:
            current, value_type = winreg.QueryValueEx(key, "Path")
        except FileNotFoundError:
            return
        kept = [item for item in str(current).split(";") if item.strip() and normalize_path(item) != normalize_path(bin_dir)]
        winreg.SetValueEx(key, "Path", 0, value_type, ";".join(kept))

    ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001A, 0, "Environment", 0x0002, 5000, None)


def remove_registry_tree(root, path: str) -> None:
    import winreg

    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ | winreg.KEY_WRITE) as key:
            while True:
                try:
                    child = winreg.EnumKey(key, 0)
                except OSError:
                    break
                remove_registry_tree(root, path + "\\" + child)
        winreg.DeleteKey(root, path)
    except FileNotFoundError:
        pass


def remove_windows_integrations(home: Path) -> None:
    if os.name != "nt":
        return
    import winreg

    remove_from_user_path(home / "bin")
    association_command = ""
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Classes\NovaDev.SourceFile\shell\open\command",
        ) as key:
            association_command, _ = winreg.QueryValueEx(key, "")
    except FileNotFoundError:
        pass

    if normalize_path(home) in normalize_path(association_command):
        remove_registry_tree(winreg.HKEY_CURRENT_USER, r"Software\Classes\.nova")
        remove_registry_tree(winreg.HKEY_CURRENT_USER, r"Software\Classes\NovaDev.SourceFile")
    extension = Path.home() / ".vscode" / "extensions" / "novadev.novadev-language-1.1.0"
    if extension.exists():
        shutil.rmtree(extension)


def schedule_removal(home: Path, parent_pid: int) -> None:
    helper_dir = Path(tempfile.mkdtemp(prefix="novadev-uninstall-"))
    helper = helper_dir / "finish_uninstall.py"
    helper.write_text(
        """import os
import shutil
import sys
import time
from pathlib import Path

home = Path(sys.argv[1]).resolve()
parent_pid = int(sys.argv[2])
for _ in range(120):
    try:
        os.kill(parent_pid, 0)
    except OSError:
        break
    time.sleep(0.25)
shutil.rmtree(home, ignore_errors=True)
shutil.rmtree(Path(__file__).resolve().parent, ignore_errors=True)
""",
        encoding="utf-8",
    )
    flags = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS if os.name == "nt" else 0
    subprocess.Popen(
        [sys.executable, str(helper), str(home), str(parent_pid)],
        cwd=str(Path.home()),
        creationflags=flags,
        close_fds=True,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Uninstall a portable NovaDev installation.")
    parser.add_argument("--home", default=os.environ.get("NOVADEV_HOME", str(Path.home() / ".novadev")))
    parser.add_argument("--yes", action="store_true", help="Do not ask for confirmation.")
    parser.add_argument("--parent-pid", type=int, default=0, help=argparse.SUPPRESS)
    args = parser.parse_args()

    home = validate_install_home(args.home)
    if not args.yes:
        answer = input(f"Remove NovaDev from {home}? User projects will be kept. [y/N] ").strip().lower()
        if answer not in {"y", "yes"}:
            print("Uninstall cancelled.")
            return 0

    remove_windows_integrations(home)
    waiting_for = args.parent_pid or os.getpid()
    schedule_removal(home, waiting_for)
    print("NovaDev uninstall scheduled.")
    print("Projects in Downloads/Nova source code were preserved.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
