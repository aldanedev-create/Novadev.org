"""NovaDev UI generation modules."""
