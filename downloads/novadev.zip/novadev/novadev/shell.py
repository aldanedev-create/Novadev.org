from __future__ import annotations

"""Package wrapper for the NovaDev 1.1 interactive shell."""

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shell import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())
