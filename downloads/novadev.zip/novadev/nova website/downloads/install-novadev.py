from __future__ import annotations

"""Bootstrap installer for NovaDev.

This file is meant to be downloaded from the NovaDev education website. It
installs a local copy of the language into ~/.novadev and creates small command
launchers so users can run nova, nova-shell, and novapm from their terminal.
"""

import argparse
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
from urllib.parse import urljoin
import urllib.request
import zipfile
from pathlib import Path


EXCLUDED_NAMES = {
    ".git",
    ".novadev",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    "dist",
    "generated_backend",
    "generated_project",
    "generated_projects",
    ".tmp-novapm-home",
}


def should_copy(path: Path) -> bool:
    if any(part.startswith(".tmp-") for part in path.parts):
        return False
    return not any(part in EXCLUDED_NAMES for part in path.parts)


def copy_tree(source: Path, target: Path) -> None:
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)

    target_resolved = target.resolve()

    def is_target_related(item: Path) -> bool:
        item_resolved = item.resolve()
        return (
            item_resolved == target_resolved
            or target_resolved in item_resolved.parents
            or item_resolved in target_resolved.parents
        )

    def copy_item(item: Path, destination: Path) -> None:
        relative = item.relative_to(source)
        if is_target_related(item) or not should_copy(relative):
            return

        if item.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            for child in item.iterdir():
                copy_item(child, destination / child.name)
        elif item.is_file():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, destination)

    for item in source.iterdir():
        copy_item(item, target / item.name)


def download_to_temp(url: str) -> Path:
    temp_dir = Path(tempfile.mkdtemp(prefix="novadev-install-"))
    target = temp_dir / "novadev-source.zip"
    urllib.request.urlretrieve(url, target)
    return target


def prepare_source(source: str | None, zip_url: str | None) -> tuple[Path, Path | None]:
    cleanup_dir = None

    if zip_url:
        archive = download_to_temp(zip_url)
        cleanup_dir = archive.parent
        extract_dir = cleanup_dir / "source"
        with zipfile.ZipFile(archive, "r") as zip_file:
            zip_file.extractall(extract_dir)
        return find_project_root(extract_dir), cleanup_dir

    if not source:
        raise SystemExit("Provide --source PATH or --zip-url URL.")

    source_path = Path(source).expanduser().resolve()
    if not source_path.exists():
        raise SystemExit(f"Source not found: {source_path}")

    if source_path.is_file() and source_path.suffix.lower() == ".zip":
        cleanup_dir = Path(tempfile.mkdtemp(prefix="novadev-install-"))
        extract_dir = cleanup_dir / "source"
        with zipfile.ZipFile(source_path, "r") as zip_file:
            zip_file.extractall(extract_dir)
        return find_project_root(extract_dir), cleanup_dir

    return source_path, None


def find_project_root(path: Path) -> Path:
    if (path / "nova.py").exists() or (path / "novapm.py").exists():
        return path

    children = [child for child in path.iterdir() if child.is_dir()]
    if len(children) == 1:
        return find_project_root(children[0])

    raise SystemExit("Could not find NovaDev project root in the provided source.")


def write_text_executable(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")
    current_mode = path.stat().st_mode
    path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def write_launchers(home: Path) -> None:
    bin_dir = home / "bin"
    language_dir = home / "language"
    python_exe = sys.executable
    bin_dir.mkdir(parents=True, exist_ok=True)

    launchers = {
        "nova": language_dir / "nova.py",
        "nova-shell": language_dir / "shell.py",
        "novapm": language_dir / "novapm.py",
    }

    for command, script in launchers.items():
        write_text_executable(
            bin_dir / f"{command}.cmd",
            f'@echo off\r\n"{python_exe}" "{script}" %*\r\n',
        )
        write_text_executable(
            bin_dir / command,
            f'#!/usr/bin/env sh\nexec "{python_exe}" "{script}" "$@"\n',
        )


def infer_registry_url(zip_url: str | None) -> str | None:
    if not zip_url:
        return None
    return urljoin(zip_url, "registry.json")


def configure_registry(home: Path, registry_url: str | None) -> None:
    if not registry_url:
        return
    home.mkdir(parents=True, exist_ok=True)
    config_path = home / "config.json"
    config_path.write_text(json.dumps({"registry": registry_url}, indent=2) + "\n", encoding="utf-8")


def read_registry(registry_url: str) -> dict:
    if registry_url.startswith(("http://", "https://")):
        with urllib.request.urlopen(registry_url, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
            data.setdefault("_registry_base_url", registry_url.rsplit("/", 1)[0] + "/")
            return data
    registry_path = Path(registry_url).expanduser().resolve()
    data = json.loads(registry_path.read_text(encoding="utf-8"))
    data.setdefault("_registry_base_path", str(registry_path.parent))
    return data


def package_names_from_registry(registry_url: str) -> list[str]:
    registry = read_registry(registry_url)
    return [package["name"] for package in registry.get("packages", []) if package.get("name")]


def run_novapm(home: Path, args: list[str]) -> None:
    novapm = home / "language" / "novapm.py"
    command = [sys.executable, str(novapm), *args, "--home", str(home)]
    subprocess.run(command, check=True)


def install_packages(home: Path, packages: list[str]) -> None:
    for package in packages:
        print(f"Installing package: {package}", flush=True)
        run_novapm(home, ["install", package])


def install(
    source: str | None,
    zip_url: str | None,
    home: Path,
    registry_url: str | None,
    package_names: list[str],
    install_all_packages: bool,
) -> None:
    project_source, cleanup_dir = prepare_source(source, zip_url)
    language_dir = home / "language"
    registry_url = registry_url or infer_registry_url(zip_url)

    try:
        home.mkdir(parents=True, exist_ok=True)
        copy_tree(project_source, language_dir)
        write_launchers(home)
        configure_registry(home, registry_url)
        packages_to_install = package_names
        if install_all_packages and registry_url:
            packages_to_install = package_names_from_registry(registry_url)
        if packages_to_install:
            install_packages(home, packages_to_install)
    finally:
        if cleanup_dir and cleanup_dir.exists():
            shutil.rmtree(cleanup_dir)

    print("NovaDev installed.")
    print(f"Home: {home}")
    print(f"Language: {language_dir}")
    print(f"Launchers: {home / 'bin'}")
    if registry_url:
        print(f"Registry: {registry_url}")
    print()
    print("Add this folder to PATH if the commands are not found:")
    print(str(home / "bin"))
    print()
    print("Try:")
    print("  nova shell")
    print("  nova run examples/hello.nova")
    print("  novapm doctor")
    if registry_url:
        print("  novapm search")


def main() -> int:
    parser = argparse.ArgumentParser(description="Install NovaDev locally.")
    parser.add_argument("--source", help="Local NovaDev source folder or zip file.")
    parser.add_argument("--zip-url", help="Download a NovaDev source zip from this URL.")
    parser.add_argument("--registry-url", help="NovaDev package registry URL or local registry path.")
    parser.add_argument("--install-package", action="append", default=[], help="Install one package after language install. Can be used more than once.")
    parser.add_argument("--install-all-packages", action="store_true", help="Install every package listed in the configured registry.")
    parser.add_argument("--home", default=str(Path.home() / ".novadev"), help="Install location.")
    args = parser.parse_args()

    install(
        args.source,
        args.zip_url,
        Path(args.home).expanduser().resolve(),
        args.registry_url,
        args.install_package,
        args.install_all_packages,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
